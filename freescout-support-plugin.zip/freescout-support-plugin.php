<?php
/**
 * @package             FreeScoutSupport
 * @author              weDevs
 * @copyright           2023 weDevs
 * @license             GPL-3.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name:         FreeScout Support Plugin
 * Plugin URI:          https://github.com/RatulHasan/freescout-support-plugin
 * Description:         FreeScout support plugin.
 * Version:             1.0.0
 * Requires PHP:        7.4
 * Requires at least:   5.6
 * Author:              weDevs
 * Author URI:          https://wedevs.com/
 * License:             GPL-2.0-or-later
 * License URI:         https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:         wedevs-free-scout
 * Domain Path:         /languages
 */

// To prevent direct access, if not define WordPress ABSOLUTE PATH then exit.
use Wedevs\FreeScoutSupport\WedevsFreeScout;

if ( ! defined( 'ABSPATH' ) ) {
    exit();
}

if ( ! file_exists( __DIR__ . '/vendor/autoload.php' ) ) {
    return;
}

require_once __DIR__ . '/vendor/autoload.php';

if ( ! defined( 'WEDEVS_FREE_SCOUT_PLUGIN_VERSION' ) ) {
    define( 'WEDEVS_FREE_SCOUT_PLUGIN_VERSION', '1.0.0' );
}

if ( ! defined( 'WEDEVS_FREE_SCOUT_PLUGIN_ASSET' ) ) {
    define( 'WEDEVS_FREE_SCOUT_PLUGIN_ASSET', plugins_url( 'assets', __FILE__ ) );
}

if ( ! defined( 'WEDEVS_FREE_SCOUT_SUPPORT_FILE' ) ) {
    define( 'WEDEVS_FREE_SCOUT_SUPPORT_FILE', __FILE__ );
}

if ( ! defined( 'WEDEVS_FREE_SCOUT_SUPPORT_DIR' ) ) {
    define( 'WEDEVS_FREE_SCOUT_SUPPORT_DIR', __DIR__ );
}

if ( ! defined( 'WEDEVS_FREE_SCOUT_SUPPORT_VERSION' ) ) {
    define( 'WEDEVS_FREE_SCOUT_SUPPORT_VERSION', '1.0.0' );
}

if ( ! defined( 'WEDEVS_FREE_SCOUT_SUPPORT_BASE_NAME' ) ) {
    define( 'WEDEVS_FREE_SCOUT_SUPPORT_BASE_NAME', plugin_basename( __FILE__ ) );
}

/**
 * Main function for FreeScout support plugin.
 *
 * @since 1.0.0
 * @return WedevsFreeScout
 */
function wedevs_free_scout_support(): WedevsFreeScout {
    return WedevsFreeScout::get_instance();
}

// Hit start the plugin.
wedevs_free_scout_support();
