<?php

namespace Wedevs\FreeScoutSupport\Traits;

trait AddMenuItems {

    /**
     * Add item to my account menu in Woocommerce.
     *
     * @since 1.0.0
     *
     * @param  string $menu_name  Menu name.
     * @param  array  $nav_items  Nav items.
     *
     * @return array
     */
    public function add_account_menu_item( string $menu_name, array $nav_items ): array {
        $old_tab = $nav_items;
        array_splice( $nav_items, 5, 2 );
        $nav_items[ $this->slug ] = $menu_name;

        return array_merge( $nav_items, $old_tab );
    }

}
