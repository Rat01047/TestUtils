<?php

namespace Wedevs\FreeScoutSupport\Traits;

trait AddRewriteEndpoint {

    /**
     * Add rewrite endpoint.
     *
     * @since 1.0.0
     *
     * @return void
     */
    public function add_rewrite_endpoint(): void {
        // $this->slug, must be implemented on parent class which uses this trait.
        if ( ! empty( $this->slug ) ) {
            add_rewrite_endpoint( $this->slug, EP_ROOT | EP_PAGES );
        }
    }

}
