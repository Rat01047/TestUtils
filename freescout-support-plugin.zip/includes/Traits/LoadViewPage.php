<?php

namespace Wedevs\FreeScoutSupport\Traits;

use Wedevs\FreeScoutSupport\Helpers\SupportScout;
use Wedevs\FreeScoutSupport\Models\FreeScout;
use Wedevs\FreeScoutSupport\Models\Settings;

trait LoadViewPage {

    /**
     * Load template for the endpoint.
     *
     * @since 1.0.0
     *
     * @param  string $value  url parameter.
     *
     * @return void
     */
    public function load_view( string $value ) {
        wp_enqueue_style( 'wedevs-free-scout-style' );
        wp_enqueue_script( 'wedevs-free-scout-script' );
        $this->get_template( $value );
    }

    /**
     * Get template based on query var.
     *
     * @since 1.0.0
     *
     * @param  string $value  url parameter.
     *
     * @return void
     */
    private function get_template( string $value ) {
        $user = wp_get_current_user();
        if ( empty( $user ) ) {
            return;
        }

        $settings = new Settings();

        if ( empty( $settings->get_api_key() ) ) {
            require_once WEDEVS_FREE_SCOUT_SUPPORT_DIR . '/includes/views/conversations.php';

            return;
        }

        $support = new SupportScout( new FreeScout( $settings ) );
        switch ( $value ) {
            case '':
                // All conversations.
                $conversations = $support->allConversations( $user->user_email );
                require_once WEDEVS_FREE_SCOUT_SUPPORT_DIR . '/includes/views/conversations.php';
                break;
            case ! empty( $value ) && 'create' === $value:
                // Create new ticket.
                $user_full_name = $user->first_name . ' ' . $user->last_name;
                require_once WEDEVS_FREE_SCOUT_SUPPORT_DIR . '/includes/views/create-new-ticket.php';
                break;
            case ! empty( $value ) && 'create' !== $value:
                // Get single conversation.
                $conversation = $support->getConversation( (int) $value );

                // phpcs:ignore
                if ( empty( $conversation->id ) || $conversation->createdBy->email !== $user->user_email ) {
                    $conversation = [];
                    require_once WEDEVS_FREE_SCOUT_SUPPORT_DIR . '/includes/views/single-conversation.php';
                    break;
                }

                $conversation_id = $conversation->id;
                $threads         = array_reverse( $conversation->_embedded->threads );

                require_once WEDEVS_FREE_SCOUT_SUPPORT_DIR . '/includes/views/single-conversation.php';
                break;
        }
    }

}
