<?php
namespace Wedevs\FreeScoutSupport\Contracts;

interface FormRequestInterface {

	/**
	 * Validate request as per fillable array.
	 *
	 * @since 1.0.0
	 */
	public function validate();

}
