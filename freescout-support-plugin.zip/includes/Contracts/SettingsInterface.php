<?php

namespace Wedevs\FreeScoutSupport\Contracts;

interface SettingsInterface {

    /**
     * Get endpoint.
     *
     * @since 1.0.0
     * @return string
     */
    public function get_endpoint(): string;

    /**
     * Get api key.
     *
     * @since 1.0.0
     * @return string
     */
    public function get_api_key(): string;

    /**
     * Get mailbox id.
     *
     * @since 1.0.0
     * @return int
     */
    public function get_mailbox_id(): int;
}
