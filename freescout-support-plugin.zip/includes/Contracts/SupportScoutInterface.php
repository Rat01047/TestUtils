<?php

namespace Wedevs\FreeScoutSupport\Contracts;

interface SupportScoutInterface {

    /**
     * Get Conversations.
     *
     * @since 1.0.0
     *
     * @param  string $email customer email.
     *
     * @return mixed
     */
    public function getConversations( string $email);

    /**
     * Get a Conversation.
     *
     * @since 1.0.0
     *
     * @param  int $conversation_id conversation id.
     *
     * @return mixed
     */
    public function getConversation( int $conversation_id);

    /**
     * Add Reply.
     *
     * @since 1.0.0
     *
     * @param  int    $conversation_id Conversation id.
     * @param  string $text text.
     * @param  string $customer_email customer id.
     * @param  string $status status.
     *
     * @return mixed
     */
    public function addReply( int $conversation_id, string $text, string $customer_email, string $status);

    /**
     * Create Conversation.
     *
     * @since 1.0.0
     *
     * @param  string            $subject Subject of that ticket.
     * @param  string            $body body of that ticket.
     * @param  CustomerInterface $customer a customer.
     *
     * @return mixed
     */
    public function createConversation( string $subject, string $body, CustomerInterface $customer);
}
