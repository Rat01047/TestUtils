<?php

namespace Wedevs\FreeScoutSupport\Contracts;

interface CustomerInterface {

    /**
     * Get First Name.
     *
     * @since 1.0.0
     * @return mixed
     */
    public function getFirstName();

    /**
     * Get Last Name.
     *
     * @since 1.0.0
     * @return mixed
     */
    public function getLastName();

    /**
     * Get Email.
     *
     * @since 1.0.0
     * @return mixed
     */
    public function getEmail();
}
