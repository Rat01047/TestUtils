<?php

namespace Wedevs\FreeScoutSupport;

use Appsero\Client;

/**
 * Tracker class
 */
class Tracker {

    private static ?Tracker $instance = null;

    private $insights;

    private Client $client;


    /**
     * Singleton instance
     */
    public static function get_instance(): ?Tracker {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }

        return self::$instance;
    }


    /**
     * Constructor
     */
    private function __construct() {
        $this->client = new Client(
            'hash-here',
            'FreeScout support plugin',
            WEDEVS_FREE_SCOUT_SUPPORT_FILE
        );

        $this->insights = $this->client->insights();
    }

    /**
     * Initialize appsero insights
     */
    public function init() {
        $this->insights->init();
    }

}
