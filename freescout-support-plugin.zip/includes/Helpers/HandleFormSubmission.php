<?php

namespace Wedevs\FreeScoutSupport\Helpers;

use Wedevs\FreeScoutSupport\Contracts\SettingsInterface;
use Wedevs\FreeScoutSupport\Models\Customer;
use Wedevs\FreeScoutSupport\Models\FreeScout;
use Wedevs\FreeScoutSupport\Models\Settings;
use Wedevs\FreeScoutSupport\Requests\AddReplySupportFormRequest;
use Wedevs\FreeScoutSupport\Requests\StoreSupportFormRequest;

class HandleFormSubmission {

    /**
     * Settings
     *
     * @var \Wedevs\FreeScoutSupport\Models\Settings
     */
    private Settings $settings;

    /**
     * Construct method.
     *
     * @param  SettingsInterface $settings  settings class.
     */
    public function __construct( SettingsInterface $settings ) {
        $this->settings = $settings;
    }

    /**
     * Create new ticket.
     *
     * @since 1.0.0
     *
     * @param  bool|array $post  Post data.
     *
     * @return mixed
     */
    public function create_new_ticket( $post = false ) {
        // phpcs:ignore
        $post           = $post ?? $_POST;
        $post = array_map( 'sanitize_text_field', $post );
        $validated_data = new StoreSupportFormRequest( $post );
        // Validation error.
        if ( ! empty( $validated_data->error ) ) {
            wp_send_json_error( $validated_data->error );
        }

        $user    = new Customer();
        $support = new SupportScout( new FreeScout( $this->settings ) );

        return $support->createConversation( $validated_data, $user );
    }

    /**
     * Add reply.
     *
     * @since 1.0.0
     *
     * @param  bool|array $post  Post data.
     *
     * @return mixed
     */
    public function add_reply( $post = false ) {
        // phpcs:ignore
        $post           = $post ?? $_POST;
        $post = array_map( 'sanitize_text_field', $post );
        $validated_data = new AddReplySupportFormRequest( $post );
        // Validation error.
        if ( ! empty( $validated_data->error ) ) {
            wp_send_json_error( $validated_data->error );
        }

        $user    = new Customer();
        $support = new SupportScout( new FreeScout( $this->settings ) );

        return $support->addReply( $validated_data->conversation_id, $validated_data, $user );
    }

}
