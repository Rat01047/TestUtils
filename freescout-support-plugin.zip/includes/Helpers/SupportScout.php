<?php

namespace Wedevs\FreeScoutSupport\Helpers;

use Wedevs\FreeScoutSupport\Contracts\CustomerInterface;
use Wedevs\FreeScoutSupport\Contracts\FormRequestInterface;
use Wedevs\FreeScoutSupport\Contracts\SupportScoutInterface;
use Wedevs\FreeScoutSupport\Models\Settings;

class SupportScout {

    /**
     * Support Scout interface.
     *
     * @var \Wedevs\FreeScoutSupport\Contracts\SupportScoutInterface
     */
    protected SupportScoutInterface $support_scout;

    /**
     * Construct method.
     *
     * @param  SupportScoutInterface $support_scout  Support Scout.
     */
    public function __construct( SupportScoutInterface $support_scout ) {
        $this->support_scout = $support_scout;
    }

    /**
     * All Conversations.
     *
     * @since 1.0.0
     *
     * @param  string $user_email  user email.
     *
     * @return mixed
     */
    public function allConversations( string $user_email ) {
        $conversations = $this->support_scout->getConversations( $user_email );

        return $conversations->_embedded ?? [];
    }

    /**
     * Store a newly created resource in storage.
     *
     * @since 1.0.0
     *
     * @param  FormRequestInterface $request  Request.
     * @param  CustomerInterface    $customer  Customer.
     *
     * @return mixed
     */
    public function createConversation( FormRequestInterface $request, CustomerInterface $customer ) {
        $subject = '' !== $request->ticket_type ? ' [ ' . Settings::get_ticket_type( $request->ticket_type ) . ' ] ' : '';
        $subject .= '' !== $request->supported_plugins ? ' [ ' . Settings::get_supported_plugins( $request->supported_plugins ) . ' ] ' : '';
        $subject .= $request->subject;

        return $this->support_scout->createConversation( $subject, wp_strip_all_tags( $request->message ), $customer );
    }

    /**
     * Get a Conversation.
     *
     * @since 1.0.0
     *
     * @param  int $id  ID of a conversation.
     *
     * @return mixed
     */
    public function getConversation( int $id ) {
        return $this->support_scout->getConversation( $id );
    }

    /**
     * Add Reply.
     *
     * @since 1.0.0
     *
     * @param  int                  $id  Conversation ID.
     * @param  FormRequestInterface $request  Request.
     * @param  CustomerInterface    $customer  Customer.
     *
     * @return mixed
     */
    public function addReply( int $id, FormRequestInterface $request, CustomerInterface $customer ) {
        return $this->support_scout->addReply( $id, wp_strip_all_tags( $request->reply ), $customer->getEmail(), $request->status );
    }

}
