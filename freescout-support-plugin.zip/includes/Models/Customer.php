<?php

namespace Wedevs\FreeScoutSupport\Models;

use Wedevs\FreeScoutSupport\Contracts\CustomerInterface;

class Customer implements CustomerInterface {

    /**
     * Wp User.
     *
     * @var \WP_User|false|null
     */
    private ?\WP_User $user;

    /**
     * Construct method.
     *
     * @param  bool|int $user_id  user id.
     */
    public function __construct( $user_id = false ) {
        if ( ! $user_id ) {
            $this->user = wp_get_current_user();
        } else {
            $this->user = get_user_by( 'id', $user_id );
        }
    }

    /**
     * Get First Name.
     *
     * @since 1.0.0
     * @return string
     */
    public function getFirstName(): string {
        return $this->user->first_name;
    }

    /**
     * Get Last Name.
     *
     * @since 1.0.0
     * @return string
     */
    public function getLastName(): string {
        return $this->user->last_name;
    }

    /**
     * Get Email.
     *
     * @since 1.0.0
     * @return string
     */
    public function getEmail(): string {
        return $this->user->user_email;
    }

}
