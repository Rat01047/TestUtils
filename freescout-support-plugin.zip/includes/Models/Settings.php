<?php

namespace Wedevs\FreeScoutSupport\Models;

use Wedevs\FreeScoutSupport\Contracts\SettingsInterface;

class Settings implements SettingsInterface {

    /**
     * Settings.
     *
     * @var false|mixed|null
     */
    protected $settings;

    /**
     * Contractor method.
     */
    public function __construct() {
        $this->settings = get_option( 'free_scout_settings', [] );
    }

    /**
     * Get free scout settings.
     *
     * @since 1.0.0
     *
     * @param  string $key  key.
     * @param  mixed  $default_return  default.
     *
     * @return false|mixed
     */
    public function get_free_scout_settings( string $key, $default_return = false ) {
        return $this->settings[ $key ] ?? $default_return;
    }

    /**
     * Get api key.
     *
     * @since 1.0.0
     * @return string
     */
    public function get_api_key(): string {
        return $this->settings['api_key'] ?? '';
    }

    /**
     * Get mailbox id.
     *
     * @since 1.0.0
     * @return int
     */
    public function get_mailbox_id(): int {
        return $this->settings['mail_box_id'] ?? 0;
    }

    /**
     * Get endpoint.
     *
     * @since 1.0.0
     * @return string
     */
    public function get_endpoint(): string {
        return $this->settings['api_endpoint_url'] ?? '';
    }

    /**
     * Get ticket type.
     *
     * @since 1.0.0
     *
     * @param  string|bool $key  type key.
     *
     * @return array|string
     */
    public static function get_ticket_type( $key = false ) {
        $type = [
            'pre_sale'       => __( 'Pre sale', 'wedevs-free-scout' ),
            'my_account'     => __( 'My account', 'wedevs-free-scout' ),
            'plugin_support' => __( 'Plugin support', 'wedevs-free-scout' ),
        ];

        if ( ! $key ) {
            return $type;
        }

        return $type[ $key ] ?? $type['pre_sale'];
    }

    /**
     * Get supported plugins.
     *
     * @since 1.0.0
     *
     * @param  string|bool $key  plugin key.
     *
     * @return array|string
     */
    public static function get_supported_plugins( $key = false ) {
        $plugins = apply_filters(
            'free_scout_supported_plugins', [
                'wp_erp'     => __( 'WP ERP', 'wedevs-free-scout' ),
                'wp_erp_pro' => __( 'WP ERP PRO', 'wedevs-free-scout' ),
            ]
        );

        if ( ! $key ) {
            return $plugins;
        }

        return $plugins[ $key ] ?? $plugins['pre_sale'];
    }

}
