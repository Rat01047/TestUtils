<?php

namespace Wedevs\FreeScoutSupport\Models;

use Wedevs\FreeScoutSupport\Contracts\CustomerInterface;
use Wedevs\FreeScoutSupport\Contracts\SettingsInterface;
use Wedevs\FreeScoutSupport\Contracts\SupportScoutInterface;

class FreeScout implements SupportScoutInterface {

    /**
     * Settings property.
     *
     * @var Settings $settings
     */
    protected Settings $settings;

    /**
     * Endpoints.
     *
     * @var string $endpoint
     */
    protected string $endpoint;

    /**
     * Mailbox.
     *
     * @var int $mailbox
     */

    /**
     * Mailbox ID.
     *
     * @var int $mailbox_id
     */
    protected int $mailbox_id;

    /**
     * Api key.
     *
     * @var string $api_key
     */
    protected string $api_key = '';

    /**
     * Construction method.
     *
     * @param  SettingsInterface $settings  SettingsInterface.
     */
    public function __construct( SettingsInterface $settings ) {
        $this->api_key    = $settings->get_api_key();
        $this->mailbox_id = $settings->get_mailbox_id();
        $this->endpoint   = $settings->get_endpoint();
    }

    /**
     * Get Request.
     *
     * @since 1.0.0
     *
     * @param  string $url  Url.
     * @param  array  $args  args.
     *
     * @return mixed|string
     */
    private function get( string $url, array $args = [] ) {
        $args = [
            'timeout' => 30,
            'headers' => [
                'X-FreeScout-API-Key' => $this->api_key,
                'Content-Type'        => 'application/json',
            ],
            'body'    => $args,
        ];

        $response = wp_safe_remote_get( $this->endpoint . $url, $args );

        if ( is_wp_error( $response ) ) {
            $error_message = $response->get_error_message();

            return "Something went wrong: $error_message";
        }

        $response = wp_remote_retrieve_body( $response );

        return json_decode( $response );
    }

    /**
     * Post request.
     *
     * @since 1.0.0
     *
     * @param  string $url  Url.
     * @param  array  $args  args.
     *
     * @return mixed|string
     */
    private function post( string $url, array $args = [] ) {
        $args = [
            'timeout' => 30,
            'headers' => [
                'X-FreeScout-API-Key' => $this->api_key,
                'Content-Type'        => 'application/json',
            ],
            'body'    => wp_json_encode( $args ),
        ];

        $response = wp_safe_remote_post( $this->endpoint . $url, $args );

        if ( is_wp_error( $response ) ) {
            $error_message = $response->get_error_message();

            return "Something went wrong: $error_message";
        }

        if ( 201 !== $response['response']['code'] ) {
            return $response['response'];
        }
        $response = wp_remote_retrieve_body( $response );

        return json_decode( $response );
    }

    /**
     * Create Conversation.
     *
     * @since 1.0.0
     *
     * @param  string            $subject  Subject of the ticket.
     * @param  string            $body  Body of the ticket.
     * @param  CustomerInterface $customer  Customer.
     *
     * @return mixed|string
     */
    public function createConversation( string $subject, string $body, CustomerInterface $customer ) {
        return $this->post(
            '/conversations', [
                'mailboxId' => $this->mailbox_id,
                'type'      => 'email',
                'subject'   => $subject,
                'customer'  => [
                    'email'     => $customer->getEmail(),
                    'firstName' => $customer->getFirstName(),
                    'lastName'  => $customer->getLastName(),
                ],
                'threads'   => [
                    [
                        'type'     => 'customer',
                        'text'     => $body,
                        'customer' => [
                            'email'     => $customer->getEmail(),
                            'firstName' => $customer->getFirstName(),
                            'lastName'  => $customer->getLastName(),
                        ],
                    ],
                ],
            ]
        );
    }

    /**
     * Get Conversations.
     *
     * @since 1.0.0
     *
     * @param  string $email  Customer email.
     *
     * @return mixed
     */
    public function getConversations( string $email ) {
        return $this->get(
            '/conversations', [
                'mailboxId'     => $this->mailbox_id,
                'customerEmail' => $email,
            ]
        );
    }

    /**
     * Get a Conversation.
     *
     * @since 1.0.0
     *
     * @param  int $conversation_id  Conversation ID.
     *
     * @return mixed|string
     */
    public function getConversation( int $conversation_id ) {
        return $this->get(
            '/conversations/' . $conversation_id, [
                'embed' => 'threads',
            ]
        );
    }

    /**
     * Add Reply.
     *
     * @since 1.0.0
     *
     * @param  int         $conversation_id  conversation ID.
     * @param  string      $text  Text.
     * @param  string      $customer_email  customer email.
     * @param  string|null $status  status.
     *
     * @return mixed|string
     */
    public function addReply( int $conversation_id, string $text, string $customer_email, $status = 'active' ) {
        return $this->post(
            '/conversations/' . $conversation_id . '/threads', [
                'type'     => 'customer',
                'text'     => $text,
                'customer' => [
                    'email' => $customer_email,
                ],
                'status'   => $status,
            ]
        );
    }

}
