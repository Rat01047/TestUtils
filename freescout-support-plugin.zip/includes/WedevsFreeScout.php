<?php

namespace Wedevs\FreeScoutSupport;

use Wedevs\FreeScoutSupport\Contracts\HookAbleInterface;
use Wedevs\FreeScoutSupport\Traits\AddRewriteEndpoint;

final class WedevsFreeScout {

    use AddRewriteEndpoint;

    /**
     * All the controller classes.
     *
     * @var array|string[]
     */
    protected array $classes = [
		'\Wedevs\FreeScoutSupport\Controllers\AjaxController',
		'\Wedevs\FreeScoutSupport\Controllers\WpErpController',
		'\Wedevs\FreeScoutSupport\Controllers\AssetsController',
		'\Wedevs\FreeScoutSupport\Controllers\WooCommerceController',
		'\Wedevs\FreeScoutSupport\Controllers\AppseroHelperController',
		'\Wedevs\FreeScoutSupport\Controllers\AdminSettingsController',
	];

    /**
     * The single instance of the class
     *
     * @since 1.0.0
     *
     * @var WedevsFreeScout
     */
    private static $instance;

    /**
     * Get the single instance of the class
     *
     * @since 1.0.0
     *
     * @return WedevsFreeScout
     */
    public static function get_instance(): WedevsFreeScout {
        if ( ! self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }


    /**
     * Construct method for WedevsFreeScout.
     */
    private function __construct() {
        add_action( 'init', [ $this, 'set_translation' ] );
        register_activation_hook( __FILE__, [ $this, 'activate_this_plugin' ] );
        add_action( 'plugins_loaded', [ $this, 'load_plugin_hooks' ] );
        $this->initiate_appsero();
    }

    /**
     * Main point of loading the plugin.
     *
     * @since 1.0.0
     *
     * @return void
     */
    public function load_plugin_hooks(): void {
        foreach ( $this->classes as $item ) {
            $item = new $item();
            if ( $item instanceof HookAbleInterface ) {
                $this->load_hooks( $item );
            }
        }
    }

    /**
     * Load necessary hooks.
     *
     * @since 1.0.0
     *
     * @param  HookAbleInterface $hook_able  HookAble Interface.
     *
     * @return void
     */
    private function load_hooks( HookAbleInterface $hook_able ): void {
        $hook_able->hooks();
    }

    /**
     * Initiate Appsero Client.
     *
     * @since 1.0.0
     * @return void
     */
    private function initiate_appsero(): void {
        // Appsero Tracker.
        Tracker::get_instance()->init();
    }

    /**
     * Set Transaction Text Domain
     *
     * @since 1.0.0
     *
     * @return void
     */
    public function set_translation() {
        load_plugin_textdomain( 'wedevs-free-scout', false, dirname( plugin_basename( WEDEVS_FREE_SCOUT_SUPPORT_FILE ) ) . '/languages' );
    }

    /**
     * On activate this plugin.
     *
     * @since 1.0.0
     *
     * @return void
     */
    public function activate_this_plugin() {
        if ( ! get_option( 'wedevs_free_scout_support_installed' ) ) {
            update_option( 'wedevs_free_scout_support_installed', time() );
        }
        update_option( 'wedevs_free_scout_support_version', WEDEVS_FREE_SCOUT_SUPPORT_VERSION );

        $this->add_rewrite_endpoint();
        flush_rewrite_rules();
    }

}
