<?php

namespace Wedevs\FreeScoutSupport\Requests;

use Wedevs\FreeScoutSupport\Core\FormRequest;

class AddReplySupportFormRequest extends FormRequest {

    protected string $nonce = 'reply_ticket_ticket_in_freescout';
    protected array $fillable = [ 'reply', 'conversation_id' ];

}
