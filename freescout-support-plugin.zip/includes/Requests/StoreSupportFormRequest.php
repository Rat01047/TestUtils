<?php

namespace Wedevs\FreeScoutSupport\Requests;

use Wedevs\FreeScoutSupport\Core\FormRequest;

class StoreSupportFormRequest extends FormRequest {

    protected string $nonce = 'create_new_ticket_in_freescout';
    protected array $fillable = [ 'subject', 'message', 'ticket_type', 'supported_plugins' ];

}
