<?php

namespace Wedevs\FreeScoutSupport\Controllers;

use Wedevs\FreeScoutSupport\Contracts\HookAbleInterface;
use Wedevs\FreeScoutSupport\Traits\AddMenuItems;
use Wedevs\FreeScoutSupport\Traits\AddRewriteEndpoint;
use Wedevs\FreeScoutSupport\Traits\LoadViewPage;

class WooCommerceController implements HookAbleInterface {

    use AddMenuItems, AddRewriteEndpoint, LoadViewPage;

    /**
     * Slug for woocommerce url.
     *
     * @var string $slug
     */
    protected string $slug = 'my-tickets';

    /**
     * Run all the available hooks.
     *
     * @since 1.0.0
     * @return void
     */
    public function hooks(): void {
        add_filter( 'woocommerce_account_menu_items', [ $this, 'add_menu_items' ] );
        add_action( 'init', [ $this, 'add_rewrite_endpoint' ] );
        add_action( "woocommerce_account_{$this->slug}_endpoint", [ $this, 'load_view' ] );
    }

    /**
     * Add item to my account menu in Woocommerce.
     *
     * @since 1.0.0
     *
     * @param  array $items  Navigation items.
     *
     * @return array
     */
    public function add_menu_items( array $items ): array {
        return $this->add_account_menu_item( __( 'Support', 'wedevs-free-scout' ), $items );
    }

}
