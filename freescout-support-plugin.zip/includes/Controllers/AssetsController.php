<?php
namespace Wedevs\FreeScoutSupport\Controllers;

use Wedevs\FreeScoutSupport\Contracts\HookAbleInterface;

class AssetsController implements HookAbleInterface {

    /**
     * Assets constructor.
     */
    public function hooks(): void {
        add_action( 'wp_enqueue_scripts', [ $this, 'register_scripts' ] );
    }

    /**
     * Load assets
     *
     * @since 1.0.0
     *
     * @return void
     */
    public function register_scripts() {
        $styles  = $this->get_styles();
        $scripts = $this->get_scripts();
        foreach ( $scripts as $handle => $script ) {
            $version = $script['version'] ?? WEDEVS_FREE_SCOUT_PLUGIN_VERSION;
            wp_register_script( $handle, $script['src'], $script['deps'], $version, true );
        }

        foreach ( $styles as $handle => $style ) {
            $deps    = $style['deps'] ?? false;
            $version = $style['version'] ?? WEDEVS_FREE_SCOUT_PLUGIN_VERSION;

            wp_register_style( $handle, $style['src'], $deps, $version );
        }

        wp_localize_script(
            'wedevs-free-scout-script', 'WeDevsFreeScout', [
                'ajax_url'        => admin_url( 'admin-ajax.php' ),
                'ticket_list_url' => home_url( 'my-tickets/' ),
                'i18n'            => [
                    'submit_btn'         => esc_html__( 'Submit Query', 'wedevs-free-scout' ),
                    'submit_btn_loading' => esc_html__( 'Creating new ticket...', 'wedevs-free-scout' ),
                    'reply_btn'          => esc_html__( 'Reply', 'wedevs-free-scout' ),
                    'reply_btn_loading'  => esc_html__( 'Replying...', 'wedevs-free-scout' ),
                    'reply_is_required' => esc_html__( 'No reply found! Reply is required.', 'wedevs-free-scout' ),
                ],
            ]
        );
    }

    /**
     * Get assets
     *
     * @since 1.0.0
     *
     * @return array[]
     */
    public function get_scripts(): array {
        return [
            'wedevs-free-scout-script' => [
                'src'     => WEDEVS_FREE_SCOUT_PLUGIN_ASSET . '/js/myaccount.js',
                'deps'    => [ 'jquery' ],
                'version' => filemtime( WEDEVS_FREE_SCOUT_SUPPORT_DIR . '/assets/css/style.css' ),
            ],
        ];
    }

    /**
     * Get registered styles.
     *
     * @since 1.0.0
     *
     * @return array[]
     */
    public function get_styles(): array {
        return [
            'wedevs-free-scout-style' => [
                'src'     => WEDEVS_FREE_SCOUT_PLUGIN_ASSET . '/css/style.css',
                'version' => filemtime( WEDEVS_FREE_SCOUT_SUPPORT_DIR . '/assets/css/style.css' ),
            ],
        ];
    }

}
