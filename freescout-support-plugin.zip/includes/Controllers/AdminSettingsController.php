<?php

namespace Wedevs\FreeScoutSupport\Controllers;

use Wedevs\FreeScoutSupport\Contracts\HookAbleInterface;
use Wedevs\FreeScoutSupport\Models\Settings;

class AdminSettingsController implements HookAbleInterface {

    /**
     * Sections.
     *
     * @var array|array[]
     */
    protected array $sections;

    /**
     * Fields
     *
     * @var array|array[]
     */
    protected array $fields;

    /**
     * Register settings property.
     *
     * @var array|array[]
     */
    protected array $register_setting;

    /**
     * All the necessary hooks.
     *
     * @since 1.0.0
     * @return void
     */
    public function hooks(): void {
        add_filter( 'plugin_action_links_' . WEDEVS_FREE_SCOUT_SUPPORT_BASE_NAME, [ $this, 'add_settings_links' ] );
        add_action( 'admin_menu', [ $this, 'add_settings_page' ] );
        add_action( 'admin_init', [ $this, 'register_settings_page' ] );
        add_filter( 'pre_update_option_free_scout_settings', [ $this, 'check_trailing_slash' ] );
    }


    /**
     * Add settings links.
     *
     * @since 1.0.0
     *
     * @param  array $links  all predefined links.
     *
     * @return array
     */
    public function add_settings_links( array $links ): array {
        $settings_links = "<a href='options-general.php?page=wedevs-freescout-support-plugin'>" . __( 'Settings', 'wedevs-free-scout' ) . '</a>';
        $settings_links = wp_kses(
            $settings_links,
            [
                'a' => [
                    'href' => [],
                ],
            ]
        );
        $links[]        = $settings_links;

        return $links;
    }

    /**
     * Callback for add options page
     *
     * @return void
     */
    public function add_settings_page() {
        add_options_page(
            __( 'FreeScout Support', 'wedevs-free-scout' ),
            __( 'FreeScout Support', 'wedevs-free-scout' ),
            'manage_options',
            'wedevs-freescout-support-plugin',
            [ $this, 'add_my_settings_page' ],
            7
        );
    }

    /**
     * Callback for add featured post
     *
     * @return void
     */
    public function add_my_settings_page() {
        include_once WEDEVS_FREE_SCOUT_SUPPORT_DIR . '/includes/views/admin-settings-page.php';
    }

    /**
     * Register settings page
     *
     * @since 1.0.0
     *
     * @return void
     */
    public function register_settings_page() {
        $settings       = new Settings();
        $this->sections = [
            [
                'id'       => 'wd_free_scout_section',
                'title'    => __( 'API Settings', 'wedevs-free-scout' ),
                'callback' => '',
                'page'     => 'wedevs-freescout-support-plugin',
            ],
        ];

        $this->register_setting = [
            [
                'option_group' => 'wedevs_free_scout_settings',
                'option_name'  => 'free_scout_settings',
            ],
        ];

        $this->fields = [
            [
                'id'       => 'api_endpoint_url',
                'title'    => __( 'API Endpoint Url', 'wedevs-free-scout' ),
                'callback' => [ $this, 'get_input_fields' ],
                'page'     => 'wedevs-freescout-support-plugin',
                'section'  => 'wd_free_scout_section',
                'args'     => [
                    'label_for'   => 'api_endpoint_url',
                    'name'        => 'free_scout_settings[api_endpoint_url]',
                    'placeholder' => 'API Endpoint Url',
                    'type'        => 'text',
                    'help_text'   => '<b>eg:</b> <code>https://demo.freescout.net/api</code>.',
                    'value'       => $settings->get_free_scout_settings( 'api_endpoint_url', '' ),
                ],
            ],
            [
                'id'       => 'api_key',
                'title'    => __( 'API Key', 'wedevs-free-scout' ),
                'callback' => [ $this, 'get_input_fields' ],
                'page'     => 'wedevs-freescout-support-plugin',
                'section'  => 'wd_free_scout_section',
                'args'     => [
                    'label_for'   => 'api_key',
                    'name'        => 'free_scout_settings[api_key]',
                    'placeholder' => 'API Key',
                    'type'        => 'text',
                    'help_text' => sprintf( '<b>%s</b>', __( 'Enter your FreeScout API KEY here', 'wedevs-free-scout' ) ),
                    'value'       => $settings->get_free_scout_settings( 'api_key', '' ),
                ],
            ],
            [
                'id'       => 'mail_box_id',
                'title'    => __( 'Mailbox id', 'wedevs-free-scout' ),
                'callback' => [ $this, 'get_input_fields' ],
                'page'     => 'wedevs-freescout-support-plugin',
                'section'  => 'wd_free_scout_section',
                'args'     => [
                    'label_for'   => 'mail_box_id',
                    'name'        => 'free_scout_settings[mail_box_id]',
                    'placeholder' => 'Mailbox id',
                    'type'        => 'text',
                    'help_text'   => '<b>eg: </b><code>1</code>',
                    'value'       => $settings->get_free_scout_settings( 'mail_box_id', '' ),
                ],
            ],
        ];

        // Call register_custom_fields to initiate all settings.
        $this->register_custom_fields( $this->sections, $this->fields, $this->register_setting );
    }

    /**
     * Register and Initialize custom fields in a section
     *
     * @param  array $sections  Data for sections.
     * @param  array $fields  Data for input fields.
     * @param  array $register_setting  Data for register information.
     *
     * @return void
     */
    private function register_custom_fields( array $sections, array $fields, array $register_setting ) {

        // add settings section.
        if ( ! empty( $sections ) ) {
            foreach ( $sections as $section ) {
                add_settings_section(
                    $section['id'],
                    $section['title'],
                    ( $section['callback'] ?? '' ),
                    $section['page']
                );
            }
        }

        // register setting.
        foreach ( $register_setting as $setting ) {
            register_setting(
                $setting['option_group'],
                $setting['option_name'],
                ( $setting['callback'] ?? '' )
            );
        }

        // add settings field.
        foreach ( $fields as $field ) {
            add_settings_field(
                $field['id'],
                $field['title'],
                ( $field['callback'] ?? '' ),
                $field['page'],
                $field['section'],
                ( $field['args'] ?? '' )
            );
        }
    }

    /**
     * Callback for post per page
     *
     * @param  array $args  for getting extra information.
     *
     * @return void
     */
    public function get_input_fields( array $args = [] ) {
        $type       = $args['type'];
        $input_type = [
            'text',
            'number',
            'password',
            'number',
            'tel',
            'file',
            'email',
            'url',
        ];

        $global_input = '<input id="' . $args['label_for'] . '" type="' . $args['type'] . '" class="regular-text" name="' . $args['name'] . '" value="' . $args['value'] . '" placeholder="Write GitHub username">';
        if ( isset( $args['help_text'] ) && ! empty( $args['help_text'] ) ) {
            $global_input .= '<p class="description">' . $args['help_text'] . '</p>';
        }
        if ( in_array( $args['type'], $input_type, true ) ) {
            $type = 'global_input';
        }

        $checkbox = '';
        if ( 'checkbox' === $args['type'] ) {
            if ( is_array( $args['value'] ) ) {
                $selected = is_array( $args['selected'] ) ? $args['selected'] : [];
                foreach ( $args['value'] as $key => $value ) {
                    $checkbox .= "<input id='{$args['label_for']}' type='{$args['type']}' name='{$args['name']}' value='{$value}' " . checked( in_array( $value, $selected, true ), 1, false ) . '>';
                }
            } else {
                $selected = $args['selected'];
                $checkbox .= "<input id='{$args['label_for']}' type='{$args['type']}' name='{$args['name']}' value='{$args['value']}' " . checked( $selected, $args['value'], false ) . '>';
            }
        }

        $radio = '';
        if ( 'radio' === $args['type'] ) {
            $selected = ! is_array( $args['selected'] ) ? $args['selected'] : '';
            foreach ( $args['value'] as $value ) {
                $radio .= "<input id='{$args['label_for']}' type='{$args['type']}' name='{$args['name']}' value='{$value}' " . checked( $selected, $value, false ) . '>';
            }
        }

        $select = '';
        if ( 'select' === $args['type'] ) {
            $select = '<select class="regular-text" id="' . $args['label_for'] . '" name="' . $args['name'] . '">';
            foreach ( $args['value'] as $value ) {
                $select .= '<option value="' . esc_attr( $value ) . '" ' . selected( esc_attr( $args['selected'] ), esc_attr( $value ), false ) . '>' . esc_html( $value ) . '</option>';
            }
            $select .= '</select>';
        }
        switch ( $type ) {
            case 'checkbox':
                echo wp_kses(
                    $checkbox,
                    [
                        'input' => [
                            'id'      => [ $args['label_for'] ],
                            'type'    => [ ' checkbox' ],
                            'name'    => [ $args['name'] ],
                            'value'   => [ $args['value'] ],
                            'checked' => [ $args['selected'] ],
                        ],
                    ]
                );
                break;
            default:
                echo wp_kses(
                    $global_input,
                    [
                        'input' => [
                            'id'    => [ $args['label_for'] ],
                            'type'  => [ $input_type ],
                            'name'  => [ $args['name'] ],
                            'value' => [],
                        ],
                        'a'     => [
                            'href' => [],
                        ],
                        'p'     => [],
                        'code'  => [],
                        'b'     => [],
                    ]
                );
                break;
        }
    }

    /**
     * Remove trailing slash from api endpoint url.
     *
     * @since 1.0.0
     *
     * @param  array $value value to be inserted.
     *
     * @return array
     */
    public function check_trailing_slash( array $value ): array {
        $value['api_endpoint_url'] = untrailingslashit( $value['api_endpoint_url'] );
        return $value;
    }

}
