<?php

namespace Wedevs\FreeScoutSupport\Controllers;

use Wedevs\FreeScoutSupport\Contracts\HookAbleInterface;
use Wedevs\FreeScoutSupport\Helpers\SupportScout;
use Wedevs\FreeScoutSupport\Models\FreeScout;
use Wedevs\FreeScoutSupport\Models\Settings;
use Wedevs\FreeScoutSupport\Traits\AddMenuItems;
use Wedevs\FreeScoutSupport\Traits\AddRewriteEndpoint;
use Wedevs\FreeScoutSupport\Traits\LoadViewPage;

class AppseroHelperController implements HookAbleInterface {

    use AddRewriteEndpoint;

    /**
     * Slug for erp url.
     *
     * @var string $slug
     */
    protected string $slug = 'my-tickets';

    /**
     * All necessary hooks.
     *
     * @since 1.0.0
     *
     * @return void
     */
    public function hooks(): void {
        add_action( 'after_appsero_myaccount_sidebar', [ $this, 'add_menu_items' ] );
        add_action( 'appsero_myaccount_custom_tab', [ $this, 'load_template' ] );
    }

    /**
     * Add item to my account menu in ERP.
     *
     * @since 1.0.0
     *
     * @param  string $tab  Navigation items.
     *
     * @return void
     */
    public function add_menu_items( string $tab ) {
        echo '<li><a href="?tab=' . $this->slug . '" class="' . ( $tab === $this->slug ? 'ama-active-tab' : '' ) . '">' . __( 'Support', 'wedevs-free-scout' ) . '</a></li>';
    }

    /**
     * Get template based on query var.
     *
     * @since 1.0.0
     *
     * @param  string $tab  Query string from url.
     *
     * @return void
     */
    public function load_template( string $tab ) {
        global $wp;

        $user = wp_get_current_user();
        if ( empty( $user ) ) {
            return;
        }

        wp_enqueue_style( 'wedevs-free-scout-style' );
        wp_enqueue_script( 'wedevs-free-scout-script' );

        $settings = new Settings();
        if ( empty( $settings->get_api_key() ) ) {
            require_once WEDEVS_FREE_SCOUT_SUPPORT_DIR . '/includes/views/conversations.php';

            return;
        }

        $support                     = new SupportScout( new FreeScout( $settings ) );
        $create_url                  = "/$wp->request?tab=create";
        $single_url_prefix           = "?tab=$this->slug";
        $single_url_ticket_id_prefix = '&id=';
        // phpcs:ignore
        $id = ! empty( $_GET[ 'id' ] ) ? $_GET[ 'id' ] : '';
        switch ( $tab ) {
            case $tab === $this->slug && '' === $id:
                // All conversations.
                $conversations = $support->allConversations( $user->user_email );
                require_once WEDEVS_FREE_SCOUT_SUPPORT_DIR . '/includes/views/conversations.php';
                break;
            case 'create' === $tab && '' === $id:
                // Create new ticket.
                $user_full_name = $user->first_name . ' ' . $user->last_name;
                require_once WEDEVS_FREE_SCOUT_SUPPORT_DIR . '/includes/views/create-new-ticket.php';
                break;
            case 'create' !== $tab && '' !== $id:
                // Get single conversation.
                $conversation = $support->getConversation( (int) $id );

                // phpcs:ignore
                if ( empty( $conversation->id ) || $conversation->createdBy->email !== $user->user_email ) {
                    $conversation = [];
                    require_once WEDEVS_FREE_SCOUT_SUPPORT_DIR . '/includes/views/single-conversation.php';
                    break;
                }

                $conversation_id = $conversation->id;
                $threads         = array_reverse( $conversation->_embedded->threads );

                require_once WEDEVS_FREE_SCOUT_SUPPORT_DIR . '/includes/views/single-conversation.php';
                break;
        }
    }

}
