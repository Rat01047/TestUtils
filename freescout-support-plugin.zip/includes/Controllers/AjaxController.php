<?php

namespace Wedevs\FreeScoutSupport\Controllers;

use Wedevs\FreeScoutSupport\Contracts\HookAbleInterface;
use Wedevs\FreeScoutSupport\Helpers\HandleFormSubmission;
use Wedevs\FreeScoutSupport\Models\Settings;

class AjaxController implements HookAbleInterface {

    /**
     * Initial ajax hooks.
     *
     * @since 1.0.0
     * @return void
     */
    public function hooks(): void {
        if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
            add_action( 'wp_ajax_create_new_ticket_in_freescout', [ $this, 'ajax_create_new_ticket' ] );
            add_action( 'wp_ajax_add_new_reply_in_freescout', [ $this, 'ajax_add_new_reply_in_freescout' ] );
        }
    }

    /**
     * Create new ticket via ajax.
     *
     * @since 1.0.0
     * @return void
     */
    public function ajax_create_new_ticket() {
        $form = new HandleFormSubmission( new Settings() );
        // phpcs:ignore
        $conversation = $form->create_new_ticket( $_POST[ 'formData' ] );
        if ( ! empty( $conversation->id ) ) {
            wp_send_json_success(
                // translators: %1$s and %2$s is anchor link.
                sprintf( __( 'Thanks for contacting with us! We will get in touch with you shortly. %1$s Go back %2$s', 'wedevs-free-scout' ), '<a class="back_button" onclick="window.history.back(); return false; ">', '</a>' ), 201
            );
        }

        wp_send_json_success(
            __( 'Ticket not created. Something went wrong.', 'wedevs-free-scout' ), 404
        );
    }

    /**
     * Create new reply via ajax.
     *
     * @since 1.0.0
     * @return void
     */
    public function ajax_add_new_reply_in_freescout() {
        $form = new HandleFormSubmission( new Settings() );
        // phpcs:ignore
        $conversation = $form->add_reply( $_POST );
        if ( ! empty( $conversation->id ) ) {
            wp_send_json_success(
                $conversation, 201
            );
        }

        wp_send_json_error(
            __( 'Ticket not created. Something went wrong.', 'wedevs-free-scout' ), 404
        );
    }

}
