<?php

namespace Wedevs\FreeScoutSupport\Controllers;

use Wedevs\FreeScoutSupport\Contracts\HookAbleInterface;
use Wedevs\FreeScoutSupport\Traits\AddMenuItems;
use Wedevs\FreeScoutSupport\Traits\AddRewriteEndpoint;
use Wedevs\FreeScoutSupport\Traits\LoadViewPage;

class WpErpController implements HookAbleInterface {

    use AddMenuItems, AddRewriteEndpoint, LoadViewPage;

    /**
     * Slug for erp url.
     *
     * @var string $slug
     */
    protected string $slug = 'my-tickets';

    /**
     * All necessary hooks.
     *
     * @since 1.0.0
     *
     * @return void
     */
    public function hooks(): void {
        add_filter( 'wp_erp_account_menu_items', [ $this, 'add_menu_items' ] );
        add_filter( 'query_vars', [ $this, 'add_query_vars' ] );
        add_action( 'init', [ $this, 'add_rewrite_endpoint' ] );
        add_action( 'wp_erp_my_account_load_custom_template', [ $this, 'load_template' ] );
    }

    /**
     * Add item to my account menu in ERP.
     *
     * @since 1.0.0
     *
     * @param  array $items  Navigation items.
     *
     * @return array
     */
    public function add_menu_items( array $items ): array {
        return $this->add_account_menu_item( __( 'Support', 'wedevs-free-scout' ), $items );
    }

    /**
     * Add query vars.
     *
     * @since 1.0.0
     *
     * @param  array $vars  Add query vars.
     *
     * @return array
     */
    public function add_query_vars( array $vars ): array {
        $vars[] = $this->slug;

        return $vars;
    }

    /**
     * Get template based on query var.
     *
     * @since 1.0.0
     *
     * @param  array $query  Query string from url.
     *
     * @return void
     */
    public function load_template( array $query ) {
        if ( isset( $query[ $this->slug ] ) ) {
            $this->load_view( $query[ $this->slug ] );

            // As wperp already enqueue this style.
            wp_dequeue_style( 'wedevs-free-scout-style' );
        }
    }

}
