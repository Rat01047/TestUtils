<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
// phpcs:disable
?>
<div class='content-padding'>
    <h2 style="font-weight: bold; margin-bottom: 20px;"><?php _e( 'Open a New Ticket', 'wedevs-free-scout' ); ?></h2>
    <div class="wperp__support-ticket-section">
        <div class="wperp__support-ticket-message">
            <p><span><?php printf( __( 'Hello <strong>%s</strong> how can we help you today?', 'wedevs-free-scout' ), $user_full_name ) ?></p>
        </div>
        <div class="support-status clearfix wperp__support-status">
            <div class="wperp__office-hour">
                <p class="office-hour">
                    <strong>Office Hour:</strong> <br>Monday - Friday <br>/ 8am - 5pm (GMT+6)
                </p>
            </div>
            <div class="wperp_our-time" id="time-diff">
                <p class="your-time-wrap">
                    <strong>Your time:</strong> <span class="local-time"><?php echo current_time( 'g:i A', 0 ); ?></span>
                </p>
            </div>
            <div class="wperp_your-time" id="time-diff">
                <p class="our-time-wrap">
                    <strong>Our time:</strong> <span class="our-time"><?php
                        $date_time = new \DateTime( 'now', new DateTimezone( 'Asia/Dhaka' ) );
                        echo $date_time->format( 'g:i A' );
                        ?></span>
                </p>
            </div>
        </div>
    </div>
    <div class='support-tab-item'>
        <div style="display: none" class='ticket_massage'></div>
        <div id='ticket-tabs'>
            <div id="pre-sales-question">
                <form class='free-scout-form-add 9 free-scout-style' action='' method='post' id='freescout_support_form'>
                    <?php
                    echo wp_nonce_field( 'create_new_ticket_in_freescout' );
                    ?>
                    <div class='free-scout-form form-label-above'>
                        <input id='type' type='hidden' name='pre_sales' size='40' />
                        <div class='free-scout-label'>
                            <label for='ticket_type'>
                                <?php _e( 'Which type of queries?', 'wedevs-free-scout' ); ?>
                                <span class="required">*</span>
                            </label>
                        </div>

                        <div>
                            <select required name="ticket_type" id="ticket_type">
                                <option value="">&mdash; <?php _e( 'Select one', 'wedevs-free-scout' ); ?> &mdash;</option>
                                <?php
                                foreach ( \Wedevs\FreeScoutSupport\Models\Settings::get_ticket_type() as $key => $item ):
                                    ?>
                                    <option value="<?php echo $key; ?>"><?php echo $item; ?></option>
                                <?php
                                endforeach;
                                ?>
                            </select>
                        </div>
                        <div style='display: none' id="all_supported_plugins">
                            <div class='free-scout-label'>
                                <label for='supported_plugins'>
                                    <?php _e( 'Which plugin?', 'wedevs-free-scout' ); ?>
                                    <span class='required'>*</span>
                                </label>
                            </div>

                            <div>
                                <select name="supported_plugins" id="supported_plugins">
                                    <option value="">&mdash; <?php _e( 'Select one', 'wedevs-free-scout' ); ?> &mdash;</option>
                                    <?php
                                    foreach ( \Wedevs\FreeScoutSupport\Models\Settings::get_supported_plugins() as $key => $item ):
                                        ?>
                                        <option value="<?php echo $key; ?>"><?php echo $item; ?></option>
                                    <?php
                                    endforeach;
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class='free-scout-label'>
                            <label for='subject'>
                                <?php _e( 'Subject', 'wedevs-free-scout' ); ?>
                                <span class='required'>*</span>
                            </label>
                        </div>

                        <div>
                            <input required id='subject' type='text' data-type='text' name='subject' size='40' />
                        </div>
                        <div class='free-scout-label'>
                            <label for='message'>
                                <?php _e( 'Message', 'wedevs-free-scout' ); ?>
                                <span class='required'>*</span>
                            </label>
                        </div>
                        <div class='free-scout-fields'>
                            <textarea required class='textareafield  free-scout_message' id='message' name='message' data-required='no' data-type='textarea' placeholder='' rows='5' cols='25'></textarea>
                        </div>
                        <div class='free-scout-label'>
                            &nbsp;
                        </div>
                        <input type='submit' class='free_scout_submit' id="create_new_ticket" name='create_new_ticket' value='<?php _e( 'Submit Query', 'wedevs-free-scout' ); ?>'>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
