<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
// phpcs:disable

global $wp;
$create_url = ! empty( $create_url ) ? $create_url : "/$wp->request/create";
$single_url_prefix = ! empty( $single_url_prefix ) ? $single_url_prefix : "/$wp->request";
$single_url_ticket_id_prefix = ! empty( $single_url_ticket_id_prefix ) ? $single_url_ticket_id_prefix : "/";
$single_ticket_url = "$single_url_prefix$single_url_ticket_id_prefix";
?>
<a href="<?php echo $create_url; ?>" class='user-signout-button open-new-ticket-btn'> <?php _e( 'Open a New Ticket', 'wedevs-free-scout' ); ?> <i
            class='fa fa-chevron-circle-right'></i></a>
<?php if ( ! empty( $conversations ) && ! empty( $conversations->conversations ) ) : ?>
    <table id="conversation-table support-conversations-table" class="wperp_conversation-table conversation-table">
        <thead>
            <tr>
                <th class="ticket-number"><?php _e( 'Number', 'erp' ); ?></th>
                <th class="ticket-subject"><?php _e( 'Subject', 'erp' ); ?></th>
                <th class="ticket-date"><?php _e( 'Date', 'erp' ); ?></th>
                <th class="ticket-status"><?php _e( 'Status', 'erp' ); ?></th>
                <th class="ticket-actions">&nbsp;</th>
            </tr>
        </thead>

        <tbody>
            <?php
			foreach ( $conversations->conversations as $conversation ) :
				$conversation_id    = intval( $conversation->id );
				$subject            = esc_attr( $conversation->subject );
				?>
            <tr>
                <td data-title="Number"># <?php echo intval( $conversation->number ); ?> </td>
                <td data-title="Subject"><a href="<?php echo "$single_ticket_url$conversation_id"; ?>"><?php echo esc_html( $subject ); ?> </a></td>
                <td data-title="Date">
				<?php
				echo date( 'Y-m-d h:i A', strtotime( $conversation->updatedAt ) );
				try {
					$modified_at = new DateTime( $conversation->createdAt, new DateTimeZone( 'UTC' ) );
					$modified_at->setTimezone( new DateTimeZone( get_option( 'timezone_string' ) ) );
					$modified_at = strtotime( $modified_at->format( 'Y-m-d H:i:s' ) );
					echo esc_html( date_i18n( get_option( 'date_format' ), $modified_at ) );
				} catch ( Exception $e ) {
					// Nothing to output when the date/time string isn't a
					// valid date/time
				}
				?>
                </td>
                <td data-title="Status"><?php echo esc_html( $conversation->status ); ?></td>
                <td data-title="Action" style="text-align: right;"><a href="<?php echo "$single_ticket_url$conversation_id"; ?>" class="conversation-button"><?php _e( 'View', 'erp' ); ?></a></td>
            </tr>
        <?php endforeach ?>
        </tbody>
    </table>
<?php else : ?>
    <div class="wperp_message_info">
        <img src="<?php echo WEDEVS_FREE_SCOUT_PLUGIN_ASSET .'/images/Support.svg'; ?>" alt="User Icon">
        <span class="order_text">Support</span>
        <span class="no__order-text"><?php _e( 'No support conversation found !', 'easy-digital-downloads' ); ?></span>
    </div>
<?php endif; ?>

<div id="conversation-wrap"></div>
