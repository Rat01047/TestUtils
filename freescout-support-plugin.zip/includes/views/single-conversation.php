<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
// phpcs:disable
?>
<div class="site-content-inner">
    <div id="primary">
        <main id="main" style="margin: 10px" role="main">
            <button style="margin-bottom: 20px" class='back_button_left user-signout-button button-primary' onclick='window.history.back(); return false; '> <?php _e( 'Go back', 'wedevs-free-scout' ); ?></button>
            <?php if ( ! empty( $conversation ) && count( $threads ) > 0 ) : ?>
                <ul id="conversation-thread">

                    <?php
                    foreach ( $threads as $thread ) :
                        if ( $thread->type == 'customer' ) :
                            $client_message = 'client-message';
                            ?>
                            <li class="<?php echo $client_message; ?>">
                                <div class="user-info">
                                    <?php echo get_avatar( $thread->createdBy->email, 60 ); ?>
                                    <span style="margin-top: 15px;margin-left: 10px;"><strong style="margin-right:2px"><?php echo $thread->createdBy->firstName . '  ' . $thread->createdBy->lastName; ?></strong> <small><?php echo date( 'Y-m-d h:i A', strtotime( $thread->createdAt ) ); ?></small></span>
                                </div>
                                <p class="thread-message"><?php echo $thread->body; ?></p>
                            </li>
                        <?php else : ?>
                            <li class="reply">
                                <div class="user-info">
                                    <?php echo get_avatar( $thread->createdBy->email, 60 ); ?>
                                </div>
                                <div class="thread-message" style="margin-top: 15px; margin-right: 70px;">
                                    <span style="margin-top: 15px;margin-left: 10px;"> <small><?php echo date( 'Y-m-d h:i A', strtotime( $thread->createdAt ) ); ?></small><strong style="color:#3863c1; margin-right:2px; margin-left: 10px;"><?php echo $thread->createdBy->firstName . '  ' . $thread->createdBy->lastName; ?></strong></span>
                                    <p><?php echo wp_kses_post( $thread->body ); ?></p>
                                </div>
                            </li>
                        <?php endif ?>
                    <?php endforeach; ?>
                </ul>
                <div id='conversation-wrap'>
                    <h3 id='conversation-thread-head'></h3>
                </div>
                <form style='padding: 10px' id='add_reply' action='' method='POST'>
                    <?php
                    echo wp_nonce_field( 'reply_ticket_ticket_in_freescout' );
                    ?>
                    <?php if ( 'closed' !== $conversation->status ) : ?>
                        <p>
                            <label for='reply'><?php _e( 'Reply', 'wedevs-free-scout' ); ?><span class='required'> * </span></label>
                            <textarea required name='reply' id='reply'></textarea>
                        </p>
                        <p style='width: 100%'>
                            <label for='mark_as_closed'>
                                <?php _e( 'Mark as closed', 'wedevs-free-scout' ); ?>
                                <input type='checkbox' id='mark_as_closed' name='mark_as_closed'>
                            </label>
                        </p>
                        <p>
                            <input type='hidden' id="conversation_id" name='conversation_id' value="<?php echo $conversation_id; ?>" />
                            <input type='submit' name="add_new_reply" id="add_new_reply" value='<?php _e( 'Reply', 'wedevs-free-scout' ); ?>' class='button conversation-reply-button' />
                        </p>
                    <?php else : ?>
                        <p id='reply_section' style="display: none">
                            <label for='reply'><?php _e( 'Reply', 'wedevs-free-scout' ); ?><span class='required'> * </span></label>
                            <textarea required name='reply' id='reply'></textarea>
                        </p>
                        <p style='width: 100%'>
                        <p><?php _e( 'This conversation is closed, You can’t reply to this conversation.', 'wedevs-free-scout' ); ?></p>
                        <p>
                            <label for='mark_as_open'>
                                <?php _e( 'Open this ticket', 'wedevs-free-scout' ); ?>
                                <input type='checkbox' id='mark_as_open' name='mark_as_open'>
                            </label>
                        </p>
                        <p id="open_ticket">
                            <input type='hidden' id="conversation_id" name='conversation_id' value="<?php echo $conversation_id; ?>" />
                            <input type='submit' name="add_new_reply" id="add_new_reply" value='<?php _e( 'Open', 'wedevs-free-scout' ); ?>' class='button conversation-reply-button' />
                        </p>
                    <?php endif ?>
                </form>
            <?php else : ?>
                <p><?php _e( 'No conversation found for this ticket.', 'wedevs-free-scout' ); ?></p>
            <?php endif ?>
        </main><!-- #main -->
    </div><!-- #primary -->

</div><!-- .site-content-inner -->
