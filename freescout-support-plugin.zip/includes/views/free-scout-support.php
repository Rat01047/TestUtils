<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
// phpcs:disable
?>
<div class="site-content-inner">
    <div id="primary" class="content-area">
        <main id="main" class="site-main" role="main">
            <h1>Hello world!</h1>
        </main><!-- #main -->
    </div><!-- #primary -->

</div><!-- .site-content-inner -->
