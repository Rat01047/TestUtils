<?php
/***
 * Settings page
 *
 * @since 1.0.0
 *
 * @author Ratul Hasan <ratuljh@gmail.com>
 *
 * @package FreeScoutSupport
 */

?>
<div class="wrap">
    <h1 class="wp-heading-inline"><?php esc_html_e( 'Freescout settings', 'wedevs-free-scout' ); ?></h1>
    <form method="post" action="options.php">
        <?php
        settings_fields( 'wedevs_free_scout_settings' );
        do_settings_sections( 'wedevs-freescout-support-plugin' );
        submit_button();
        ?>
    </form>
</div>
