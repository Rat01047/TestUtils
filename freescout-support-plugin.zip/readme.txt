=== FreeScout Support Plugin | A FreeScout support solution with Woocommerce, Appsero Helper and wperp.com   ===
Contributors: tareq1988, nizamuddinbabu, wedevs
Donate Link: https://tareq.co/donate
Tags:  FreeScout, Support
Requires at least: 5.6
Tested up to: 6.1.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


== Changelog ==

= v1.0.0 -> February 10, 2023 =
--------------------------

- [Feature] - Integration with wperp.com.
- [Feature] - Integration with Woocommerce.
- [Feature] - Integration with Appsero helper.
